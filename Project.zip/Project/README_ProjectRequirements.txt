﻿How we met the Project Requirements

Database:

	Structure-
		Using phpMyAdmin, we created mySQL tables online that contained all our data.
		Server = "sql9.freemysqlhosting.net";
		User = "sql9269783";
		Password = "WQImnUYV2L";
		Database = "sql9269783";
	Data-
		The Data we ended up using was User Data and Outfit Data.
		User Data was saved when new log in accounts were made.
		Outfit data was saved every time a user made an outfit.
		Their table names were 'userLogin' and 'outfit' respectively.

	Connectivity-
		Because the SQL server is online, in order for anything to work
		the connectivity of our server and the database have to work together.

Web API:
	REST- 
		Used GETs to get our data from the database and Used POST in order to
		make sure the only person who could access the API page was the user with 
		the username 'admin'.
	MVC- 
		Used MVC framework and folders in order to make the navigation and work of
		process more streamlined.
	Clear- 
		All code has intuitive names, variables, and functions. Comments are there 
		when necessary.

Client:
	Clear- 
		All code has intuitive names, variables, and functions. Comments are there 
		when necessary.
	Visual Appeal-
		CSS of main page was made to make the content look appealing.
	Usability- 
		There are a lot of labels and buttons that inform the user of where to go
		and the options they have.
Check-Ins
	Progress- 
		Every time we met with the TA, we had made more progress on what we were
		working on.
	Attendance- 
		Tried to communicate with TA to find times when it would be best to meet
		and members would try their best to make meetings, and when they were
		unable to because of conflicting schedule, the TA was made aware beforehand.
Peer Review
	We all rate each other as 10/10.
