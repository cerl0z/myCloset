<html>
<head></head>

<body>

<?php 

echo "<table border ='1' style='border-collapse: collapse;'>";
echo "
<tr>
<th>Username</th>
<th>Password</th>
<th>User ID</th>
</tr>";

?>

</body>
</html>