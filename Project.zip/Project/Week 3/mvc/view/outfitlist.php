<html>
<head></head>

<body>


<?php

echo "<table border ='2', style='border-collapse: collapse;'>";
echo "
<tr>
<th>Outfit Name</th>
<th>Outfit ID</th>
<th>Gender</th>
<th>Skin Color</th>

<th>Top</th>
<th>Top Color</th>
<th>Bottom</th>
<th>Bottom Color</th>
<th>User ID</th>
<th>Season</th>
</tr>";
?>
</body>
</html>